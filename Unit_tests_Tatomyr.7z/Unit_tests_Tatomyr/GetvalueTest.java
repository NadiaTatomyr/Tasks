import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by Nadiia_Tatomyr on 9/7/2016.
 */

public class GetvalueTest {
    @Test
    public void getValueFromIndex() throws Exception {
        int index = 2;
        int [] array = {2, 3, 5, 6, 7};

        //Block 2
        Getvalue getValue = new Getvalue();
        int result = getValue.getValueFromIndex(index, array);
        Assert.assertEquals(5, result);
    }

    @Test
    public void getSum() throws Exception {
        Getvalue getValue = new Getvalue();
        int sum = getValue.getSum(4,6);
        Assert.assertEquals(10, sum);

    }

    @Test(expected=ArithmeticException.class)
    public void division1(){
        Getvalue getValue = new Getvalue();
        int res = getValue.division1(3,0);
    }

    @Test
    public void mult1(){
        Getvalue getValue = new Getvalue();
        int res = getValue.multiplication(50,8);
        Assert.assertEquals(400, res);
    }

    @Test
    public void substraction(){
        Getvalue getValue = new Getvalue();
        int res = getValue.substraction(50,3);
        if (res!=47) {Assert.fail("Error!");}
        //Assert.assertEquals(53, res);
    }

}