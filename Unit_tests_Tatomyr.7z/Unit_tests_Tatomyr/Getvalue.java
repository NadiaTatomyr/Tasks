import java.util.Arrays;

/**
 * Created by Nadiia_Tatomyr on 9/7/2016.
 */

public class Getvalue {

    public int getValueFromIndex(int index, int[] array) {

        int result = array[index];
        //System.out.println(Arrays.toString(array));
        //System.out.println(index);
        return result;
    }

    public int getSum(int a, int b)
    {
        int sum = a+b;
        return sum;
    }

    public int division1(int a, int b)
    {
        return a/b;
    }

    public int multiplication(int a, int b)
    {
        return a*b;
    }

    public int substraction(int a, int b)
    {
        return a-b;
    }

}
